﻿namespace ProyectoPolerasMVC.Models
{
    public class Poleras
    {
        public int id { get; set; }
        public string? nombre { get; set; }
        public string? talla { get; set; }
        public string? descripcion { get; set; }


    }
}
