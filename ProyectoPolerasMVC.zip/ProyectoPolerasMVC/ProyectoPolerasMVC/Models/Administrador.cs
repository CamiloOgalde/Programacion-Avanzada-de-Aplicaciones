﻿namespace ProyectoPolerasMVC.Models
{
    public class administrador
    {
        public string? nomb_admin { get; set; }
        public string? contraseña_admin { get; set; }
    }
}
