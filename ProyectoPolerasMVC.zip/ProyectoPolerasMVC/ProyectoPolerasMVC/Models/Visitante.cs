﻿namespace ProyectoPolerasMVC.Models
{
    public class Visitante
    {
        public int nomb_Registro { get; set; }
       
        public int contraseña_Registro { get; set; }

        public string? correo_Registro { get; set; }
    }
}
