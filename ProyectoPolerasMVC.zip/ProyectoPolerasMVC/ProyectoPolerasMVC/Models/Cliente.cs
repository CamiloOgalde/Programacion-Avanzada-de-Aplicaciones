﻿namespace ProyectoPolerasMVC.Models
{
    public class Cliente
    {
        public int id  { get; set; } 

        public string? nombre_Cliente { get; set; }

        public string? apellido_Cliente { get; set; }

        public string? rut_Cliente { get; set; }

        public int telefono_Cliente { get; set; }

        public string? correo_Cliente { get; set; }

        public string? region_Cliente { get; set; }

        public string? comuna_Cliente { get; set; }

        public string? calle_Cliente { get; set; }

        public string? numCasa_Cliente { get; set; }

        public string? numDepto_Cliente { get; set; }
    }
}
