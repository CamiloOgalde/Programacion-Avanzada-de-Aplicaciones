﻿namespace ProyectoPolerasMVC.Models
{
    public class Genero
    {
        public int id { get; set; }
        public string? nom_genero { get; set; }
    }
}
