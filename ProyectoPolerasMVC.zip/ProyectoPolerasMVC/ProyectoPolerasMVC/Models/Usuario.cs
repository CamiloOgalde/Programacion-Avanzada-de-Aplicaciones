﻿namespace ProyectoPolerasMVC.Models
{
    public class Usuario
    {

        public string? nomb_Usuario  { get; set; }
        public string? contraseña_Usuario { get; set; }

    }
}
