﻿namespace ProyectoPolerasMVC.Models
{
    public class Comprar
    {
        public int id { get; set; }
    }
}
