﻿
namespace ProyectoPolerasMVC.Models
{
    public class Carrito
    {
        public string? producto { get; set; }
        public int precio { get; set; }
        public string? cantidad { get; set; }
        public int subtotal { get; set; }
        public int total { get; set; }
    }
}
