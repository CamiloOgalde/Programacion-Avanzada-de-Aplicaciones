﻿namespace ProyectoPolerasMVC.Models
{
    public class Categoria
    {
        public int id { get; set; }
        public string? nomb_categoria { get; set; }
    }
}
