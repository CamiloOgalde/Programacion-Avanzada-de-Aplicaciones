﻿namespace ProyectoPolerasMVC.Models
{
    public class Pagar
    {
        public int id { get; set; }
        public string? MetodoPago { get; set; }
    }
}
