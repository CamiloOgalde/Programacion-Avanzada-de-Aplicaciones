﻿using Microsoft.AspNetCore.Mvc;

namespace ProyectoPolerasMVC.Controllers
{
    public class CategoriaController : Controller
    {

        public IActionResult Index()
        {

            ViewBag.Nombre1 = "Rock";
            ViewBag.Nombre2 = "Metal";
            ViewBag.Nombre3 = "Punk";


            return View();
        }

    }
}
