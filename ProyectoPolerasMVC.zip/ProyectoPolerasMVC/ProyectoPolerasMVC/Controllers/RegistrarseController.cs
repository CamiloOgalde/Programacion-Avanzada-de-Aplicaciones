﻿using Microsoft.AspNetCore.Mvc;

namespace ProyectoPolerasMVC.Controllers
{
    public class RegistrarseController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
