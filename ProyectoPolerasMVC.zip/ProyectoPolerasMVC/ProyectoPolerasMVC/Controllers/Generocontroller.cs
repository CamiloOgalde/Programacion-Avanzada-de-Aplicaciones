﻿using Microsoft.AspNetCore.Mvc;

namespace ProyectoPolerasMVC.Controllers
{
    public class Generocontroller : Controller
    {
        public IActionResult Index()
        {

            ViewBag.Nombre1 = "Hombre";
            ViewBag.Nombre2 = "Mujer";

            return View();
        }
    }
}
