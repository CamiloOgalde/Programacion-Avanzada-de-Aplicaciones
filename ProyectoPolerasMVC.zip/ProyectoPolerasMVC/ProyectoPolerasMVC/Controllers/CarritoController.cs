﻿using Microsoft.AspNetCore.Mvc;
using ProyectoPolerasMVC.Models;


namespace ProyectoPolerasMVC.Controllers
{
    public class CarritoController : Controller
    {
       
        public IActionResult Index( )
        {
             List<Carrito> carrito = new List<Carrito>{

                new Carrito() { producto = "Polera Hombre The Doors Talla XL", precio = 9990 , cantidad = "1", subtotal = 9990,total = 7990} ,
                new Carrito() { producto = "Polera Hombre The Police Talla M"  , precio = 9990, cantidad = "2", subtotal = 18990,total = 18990} ,
                new Carrito() { producto = "Polera Hombre Led Zepellin Talla S"  , precio = 9990, cantidad = "1", subtotal = 9990,total = 7990} ,

            };
            return View(carrito);

        }
         
    }
}
